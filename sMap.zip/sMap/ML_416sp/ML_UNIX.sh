#!/bin/bash


for i in ~/Documents/troph_inference/smap/no_threshold_analysis/models/ML_models/size.model.ML*; do

	foldername=$i
	foldername=${foldername::-4}
	f=$(basename "$foldername")

	mkdir ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/$f

echo $f
sMap -t ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/consensus_tree_normalized.txt -d ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/no_thresh_verified_size.txt -o ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/$f/$f -n 1000 -i $i 
done

mkdir ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/size_ARD
sMap -t ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/consensus_tree_normalized.txt -d ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/no_thresh_verified_size.txt -o ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/size_ARD/size_ARD -n 1000 



for i in ~/Documents/troph_inference/smap/no_threshold_analysis/models/ML_models/gam_model_ML*; do

        foldername=$i
        foldername=${foldername::-4}
        f=$(basename "$foldername")

        mkdir ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/$f

echo $f
sMap -t ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/consensus_tree_normalized.txt -d ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/no_thresh_verified_gam.txt -o ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/$f/$f -n 1000 -i $i 
done

mkdir ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/gam_ARD
sMap -t ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/consensus_tree_normalized.txt -d ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/no_thresh_verified_gam.txt -o ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/gam_ARD/gam_ARD -n 1000







for i in ~/Documents/troph_inference/smap/no_threshold_analysis/models/ML_models/sting_model_ML*; do

        foldername=$i
        foldername=${foldername::-4}
        f=$(basename "$foldername")

        mkdir ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/$f

echo $f
sMap -t ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/consensus_tree_normalized.txt -d ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/no_thresh_verified_sting.txt -o ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/$f/$f -n 1000 -i $i 
done

mkdir ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/sting_ARD
sMap -t ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/consensus_tree_normalized.txt -d ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/no_thresh_verified_sting.txt -o ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/sting_ARD/sting_ARD -n 1000







for i in ~/Documents/troph_inference/smap/no_threshold_analysis/models/ML_models/troph_model_ML*; do

        foldername=$i
        foldername=${foldername::-4}
        f=$(basename "$foldername")

        mkdir ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/$f

echo $f
sMap -t ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/consensus_tree_normalized.txt -d ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/no_thresh_verified_troph.txt -o ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/$f/$f -n 1000 -i $i 
done

mkdir ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/troph_ARD
sMap -t ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/consensus_tree_normalized.txt -d ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/no_thresh_verified_troph.txt -o ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/troph_ARD/troph_ARD -n 1000




for i in ~/Documents/troph_inference/smap/no_threshold_analysis/models/ML_models/liq_model_ML*; do

        foldername=$i
        foldername=${foldername::-4}
        f=$(basename "$foldername")

        mkdir ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/$f

echo $f
sMap -t ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/consensus_tree_normalized.txt -d ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/no_thresh_verified_liq.txt -o ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/$f/$f -n 1000 -i $i 
done

mkdir ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/liq_ARD
sMap -t ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/consensus_tree_normalized.txt -d ~/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/no_thresh_verified_liq.txt -o ~/Documents/troph_inference/smap/no_threshold_analysis/ML_analysis_416_sp/output/liq_ARD/liq_ARD -n 1000


