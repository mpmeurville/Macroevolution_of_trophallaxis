#!/bin/bash


#Gam : Gam ARD = 100%
mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/gam_blended

cp /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/gam_ARD/gam_ARD.smap.bin /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/gam_blended/gam.blended.smap.bin


#Liq
mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/liq_blended

Blend-sMap -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/liq_blended/liq.blended.smap.bin -n 5000 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/liq_ARD/liq_ARD.smap.bin,0.75 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/liq_model_Bayes_ER/liq_model_Bayes_ER.smap.bin,0.25

#Size
mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/size_blended

Blend-sMap -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/size_blended/size.blended.smap.bin -n 5000 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/size_ARD/size_ARD.smap.bin,0.51 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/size.model.Bayes.ORD1_ARD/size.model.Bayes.ORD1_ARD.smap.bin,0.38 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/size.model.Bayes.ORD1_ER/size.model.Bayes.ORD1_ER.smap.bin,0.05 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/size.model.Bayes.ORD1_SYM/size.model.Bayes.ORD1_SYM.smap.bin,0.03 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/size.model.Bayes.SYM/size.model.Bayes.SYM.smap.bin,0.03

#Sting
mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/sting_blended

Blend-sMap -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/sting_blended/sting.blended.smap.bin -n 5000 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/sting_ARD/sting_ARD.smap.bin,0.35 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/sting_model_Bayes_ER/sting_model_Bayes_ER.smap.bin,0.65

#Troph
mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/troph_blended


cp /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/troph_ARD/troph_ARD.smap.bin /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/troph_blended/troph.blended.smap.bin


