In this whole folder, we run the analyses on a dataset that is composed of:
        Species with KNOWN trophallaxis status
        Species with IMPUTED then VERIFIED trophallaxis status
	-> This is because we want to avoid circularity by using imputed data

# Following commented steps previously computed in /home/meurvill/Documents/troph_inference/data_for_paper/sMap_analyses/ML_analysis_211_sp and /home/meurvill/Documents/troph_inference/data_for_paper/sMap_analyses/ML_analysis_416_sp

# 00: Production of the files done with R.
# 01: Setting the models for the ML analysis. Run the srcipt ML_UNIX.sh.
# -> The output is in ~/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/ML_analysis


# 02: tail -n +1 */*mean.params* > ml_estimates_ML_all.txt
# -> To extract all the rates and build the empirical bayesian models.
# -> In the resulting .txt, remove the "output" part.

#    tail -n +1 */*modelstat.txt* > modelstat_ML.txt
# -> Extract AIC, BIC etc.
# -> In the resulting .txt, remove the "output" part.

03: Produce empirical Bayesian models: ~/Documents/troph_inference/smap/no_threshold_analysis/models/Bayes_Dtest

04: Upload Empirical Bayesian models on the computer and launch Bayes_UNIX_pp.sh

05: Collect the marg likelihood values ( tail */*marginal.likelihood.txt> marg_likelihood.txt) for every model and calculate the weights : https://docs.google.com/spreadsheets/d/1md_IuRSf2DK05ctohloeGKb9IYHehIPDNnmHAlWeQo8/edit#gid=2046433936 on page Dtest_all_sp_no_thresh

06: Blend the Bayesian models together with the appropriate weights using blend_Bayes.sh

07: Merge models two by two: script merge_Bayes_pp.sh

08: Launch the dtests: dtests.sh

09: transfer the files on the computer :
        scp -r meurvill@biolpc182:~/Documents/troph_inference/smap/dataset_pred_verif/* D>




