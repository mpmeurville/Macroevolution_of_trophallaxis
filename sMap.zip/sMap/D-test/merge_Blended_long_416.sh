#!/bin/bash


Merge-sMap -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/merge/troph_liq_merged.smap.bin -n 2000 -s "/home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/troph_blended/troph.blended.smap.bin;0" -s "/home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/liq_blended/liq.blended.smap.bin;0"

Merge-sMap -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/merge/troph_gam_merged.smap.bin -n 2000 -s "/home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/troph_blended/troph.blended.smap.bin;0" -s "/home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/gam_blended/gam.blended.smap.bin;0"

Merge-sMap -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/merge/troph_size_merged.smap.bin -n 2000 -s "/home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/troph_blended/troph.blended.smap.bin;0" -s "/home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/size_blended/size.blended.smap.bin;0"

Merge-sMap -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/merge/troph_sting_merged.smap.bin -n 2000 -s "/home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/troph_blended/troph.blended.smap.bin;0" -s "/home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/416_sp/long/blended/sting_blended/sting.blended.smap.bin;0"
