#!/bin/bash


Stat-sMap -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/merge/troph_sting_merged.smap.bin -t 0 1 /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/dtest/troph_sting.dtest

Stat-sMap -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/merge/troph_liq_merged.smap.bin -t 0 1 /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/dtest/troph_liq.dtest


Stat-sMap -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/merge/troph_gam_merged.smap.bin -t 0 1 /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/dtest/troph_gam.dtest

Stat-sMap -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/merge/troph_size_merged.smap.bin -t 0 1 /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/dtest/troph_size.dtest
