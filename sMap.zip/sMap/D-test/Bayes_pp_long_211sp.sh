#!/bin/bash


for i in /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/models/Bayesian_211/troph*; do

        foldername=$i
        foldername=${foldername::-4}
        f=$(basename "$foldername")

        mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/$f

echo $f

# echo $foldername
sMap -t /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/211_sp/consensus_tree_normalized.txt -d /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/211_sp/no_thresh_Dtest_troph.txt -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/$f/$f -n 1000 -i $i -ss --max-samples=200000 --nt 24 --pm 5 --pp 100
done

for i in /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/models/Bayesian_211/size*; do

        foldername=$i
        foldername=${foldername::-4}
        f=$(basename "$foldername")

        mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/$f

echo $f

# echo $foldername
sMap -t /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/211_sp/consensus_tree_normalized.txt -d /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/211_sp/no_thresh_Dtest_size.txt -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/$f/$f -n 1000 -i $i -ss --max-samples=200000 --nt 24 --pm 5 --pp 100
done

for i in /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/models/Bayesian_211/sting*; do

        foldername=$i
        foldername=${foldername::-4}
        f=$(basename "$foldername")

        mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/$f

echo $f

# echo $foldername
sMap -t /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/211_sp/consensus_tree_normalized.txt -d /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/211_sp/no_thresh_Dtest_sting.txt -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/$f/$f -n 1000 -i $i -ss --max-samples=200000 --nt 24 --pm 5 --pp 100
done

for i in /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/models/Bayesian_211/gam*; do

        foldername=$i
        foldername=${foldername::-4}
        f=$(basename "$foldername")

        mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/$f

echo $f

# echo $foldername
sMap -t /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/211_sp/consensus_tree_normalized.txt -d /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/211_sp/no_thresh_Dtest_gam.txt -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/$f/$f -n 1000 -i $i -ss --max-samples=200000 --nt 24 --pm 5 --pp 100
done

for i in /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/models/Bayesian_211/liq*; do

        foldername=$i
        foldername=${foldername::-4}
        f=$(basename "$foldername")

        mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/$f

echo $f

# echo $foldername
sMap -t /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/211_sp/consensus_tree_normalized.txt -d /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/211_sp/no_thresh_Dtest_liq.txt -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Dtest/output/211_sp/long/$f/$f -n 1000 -i $i -ss --max-samples=200000 --nt 24 --pm 5 --pp 100
done
