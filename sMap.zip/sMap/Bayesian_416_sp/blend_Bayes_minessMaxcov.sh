#!/bin/bash


#Gam : Gam ARD = 100%
mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/blended/gam_blended

cp /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/gam_ARD/gam_ARD.smap.bin /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/blended/gam_blended/.


#Liq
mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/blended/liq_blended

Blend-sMap -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/blended/liq_blended/liq.blended.smap.bin -n 5000 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/liq_ARD/liq_ARD.smap.bin,0.75 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/liq_model_Bayes_ER/liq_model_Bayes_ER.smap.bin,0.25

#Size
mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/blended/size_blended

Blend-sMap -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/blended/size_blended/size.blended.smap.bin -n 5000 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/size_ARD/size_ARD.smap.bin,0.60 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/size.model.Bayes.ORD1_ARD/size.model.Bayes.ORD1_ARD.smap.bin,0.30 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/size.model.Bayes.ORD1_ER/size.model.Bayes.ORD1_ER.smap.bin,0.04 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/size.model.Bayes.ORD1_SYM/size.model.Bayes.ORD1_SYM.smap.bin,0.03 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/size.model.Bayes.SYM/size.model.Bayes.SYM.smap.bin,0.03

#Sting
mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/blended/sting_blended

Blend-sMap -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/blended/sting_blended/sting.blended.smap.bin -n 5000 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/sting_ARD/sting_ARD.smap.bin,0.34 -s /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/sting_model_Bayes_ER/sting_model_Bayes_ER.smap.bin,0.66

#Troph = 100%
mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/blended/troph_blended

cp /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/troph_ARD/troph_ARD.smap.bin /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/miness_maxcov/blended/troph_blended/.

