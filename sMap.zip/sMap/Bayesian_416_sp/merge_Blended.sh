#!/bin/bash


Merge-sMap -o output/merged/troph_liq_merged.smap.bin -n 2000 -s "output/blended/troph_blended/troph_ARD.smap.bin;0" -s "output/blended/liq_blended/liq.blended.smap.bin;0"

Merge-sMap -o output/merged/troph_gam_merged.smap.bin -n 2000 -s "output/blended/troph_blended/troph_ARD.smap.bin;0" -s "output/blended/gam_blended/gam_ARD.smap.bin;0"

Merge-sMap -o output/merged/troph_size_merged.smap.bin -n 2000 -s "output/blended/troph_blended/troph_ARD.smap.bin;0" -s "output/blended/size_blended/size.blended.smap.bin;0"

Merge-sMap -o output/merged/troph_sting_merged.smap.bin -n 2000 -s "output/blended/troph_blended/troph_ARD.smap.bin;0" -s "output/blended/sting_blended/sting.blended.smap.bin;0"
