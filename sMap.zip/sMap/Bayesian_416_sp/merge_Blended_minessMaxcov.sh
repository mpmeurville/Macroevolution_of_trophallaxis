#!/bin/bash


Merge-sMap -o output/merged_miness_maxcov/troph_liq_merged.smap.bin -n 2000 -s "output/blended_miness_maxcov/troph_blended/troph_ARD.smap.bin;0" -s "output/blended_miness_maxcov/liq_blended/liq.blended.smap.bin;0"

Merge-sMap -o output/merged_miness_maxcov/troph_gam_merged.smap.bin -n 2000 -s "output/blended_miness_maxcov/troph_blended/troph_ARD.smap.bin;0" -s "output/blended_miness_maxcov/gam_blended/gam_ARD.smap.bin;0"

Merge-sMap -o output/merged_miness_maxcov/troph_size_merged.smap.bin -n 2000 -s "output/blended_miness_maxcov/troph_blended/troph_ARD.smap.bin;0" -s "output/blended_miness_maxcov/size_blended/size.blended.smap.bin;0"

Merge-sMap -o output/merged_miness_maxcov/troph_sting_merged.smap.bin -n 2000 -s "output/blended_miness_maxcov/troph_blended/troph_ARD.smap.bin;0" -s "output/blended_miness_maxcov/sting_blended/sting.blended.smap.bin;0"
