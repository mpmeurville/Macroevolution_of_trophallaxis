#!/bin/bash


for i in /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/models/Bayesian_416/troph*; do

        foldername=$i
        foldername=${foldername::-4}
        f=$(basename "$foldername")

        mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/long/$f

echo $f

# echo $foldername
sMap -t /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/consensus_tree_normalized.txt  -d /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/no_thresh_verified_troph.txt -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/long/$f/$f -n 1000 -i $i -ss --max-samples=200000 --nt 24 --pm 5 
done

for i in /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/models/Bayesian_416/size*; do

        foldername=$i
        foldername=${foldername::-4}
        f=$(basename "$foldername")

        mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/long/$f

echo $f

# echo $foldername
sMap -t /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/consensus_tree_normalized.txt  -d /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/no_thresh_verified_size.txt -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/long/$f/$f -n 1000 -i $i -ss --max-samples=200000 --nt 24 --pm 5 
done

for i in /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/models/Bayesian_416/sting*; do

        foldername=$i
        foldername=${foldername::-4}
        f=$(basename "$foldername")

        mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/long/$f

echo $f

# echo $foldername
sMap -t /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/consensus_tree_normalized.txt  -d /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/no_thresh_verified_sting.txt -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/long/$f/$f -n 1000 -i $i -ss --max-samples=200000 --nt 24 --pm 5 
done

for i in /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/models/Bayesian_416/gam*; do

        foldername=$i
        foldername=${foldername::-4}
        f=$(basename "$foldername")

        mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/long/$f

echo $f

# echo $foldername
sMap -t /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/consensus_tree_normalized.txt  -d /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/no_thresh_verified_gam.txt -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/long/$f/$f -n 1000 -i $i -ss --max-samples=200000 --nt 24 --pm 5 
done

for i in /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/models/Bayesian_416/liq*; do

        foldername=$i
        foldername=${foldername::-4}
        f=$(basename "$foldername")

        mkdir /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/long/$f

echo $f

# echo $foldername
sMap -t /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/consensus_tree_normalized.txt  -d /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/input/416_sp/no_thresh_verified_liq.txt -o /home/meurvill/Documents/troph_inference/smap/no_threshold_analysis/Bayesian_416_sp/output/long/$f/$f -n 1000 -i $i -ss --max-samples=200000 --nt 24 --pm 5 


done
